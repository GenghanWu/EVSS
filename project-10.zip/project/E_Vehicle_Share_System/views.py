from django.shortcuts import redirect, render
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, logout
from .models import User
from .forms import *
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from .models import Vehicle, Customer, Operator, Manager
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')
from geopy.geocoders import Nominatim
import numpy as np
import pandas as pd
import os
from enum import Enum
from decimal import Decimal

#def members(request):
#    return HttpResponse("Hello world!")

# charge pre second
charge_per_sec = 0.01

# battery loss 1 percent need how much second
battery_loss_frequency_in_sec = 600

# record file path
record_path = './record/'

# static path
static_path = './E_Vehicle_Share_System/static/E_Vehicle_Share_System/'

# defind close distance in km
distance = 2

# glasgow boundary
lon_max = -4.05
lon_min = -4.41	
lat_max = 55.94
lat_min = 55.73

class record_type(Enum):
    CUSTOMER = 'customer'
    OPERATOR = 'operator'
    VEHICLE = 'vehicle'

class operations(Enum):
    CREATE = 'create'
    LOGIN = 'login'
    RENT = 'rent'
    RETURN = 'return'
    REPORT = 'report'
    PAY = 'pay'
    TRACK = 'track'
    CHARGE = 'charge'
    REPAIR = 'repair'
    MOVE = 'move'

# pip install geopy
def get_address(latitude, longitude):
    geolocator = Nominatim(user_agent="geoapi")
    location = geolocator.reverse((latitude, longitude), exactly_one=True)
    try :
        return location.address
    except Exception as e:
        print(e)

def get_record(record_type_value):
    record_name = os.path.join(record_path, record_type_value + '_record.xlsx')
    try:
        df = pd.read_excel(record_name)
    except Exception as e:
        if not os.path.exists(record_path):
            os.makedirs(record_path)
        if record_type_value == 'customer':
            df = pd.DataFrame(columns=['time', 'user_id', 'operation', 'payment', 'vehicle_id', 'lat', 'lon', 'location', 'battery_level', 'vehicle_charge', 'charge'])
        elif record_type_value == 'operator':
            df = pd.DataFrame(columns=['time', 'user_id', 'operation', 'vehicle_id', 'lat', 'lon', 'location', 'battery_level'])
        elif record_type_value == 'vehicle':
            df = pd.DataFrame(columns=['time', 'vehicle_id', 'lat', 'lon', 'battery_level', 'location', 'vehicle_type', 'status_type'])
    return df
    
def write_record(type, record):
    def to_record(record_type_value, df):
        record_name = os.path.join(record_path, record_type_value + '_record.xlsx')
        df.to_excel(record_name, index=False)

    if record_type.CUSTOMER == type:
        df = get_record(record_type.CUSTOMER.value)
        new_df = pd.DataFrame([record])
        df = pd.concat([df, new_df], ignore_index=True)
        to_record(record_type.CUSTOMER.value, df)
    elif record_type.OPERATOR == type:
        df = get_record(record_type.OPERATOR.value)
        new_df = pd.DataFrame([record])
        df = pd.concat([df, new_df], ignore_index=True)
        to_record(record_type.OPERATOR.value, df)
    elif record_type.VEHICLE == type:
        df = get_record(record_type.VEHICLE.value)
        new_df = pd.DataFrame([record])
        df = pd.concat([df, new_df], ignore_index=True)
        to_record(record_type.VEHICLE.value, df)

def cal_dis(lat1, lon1, lat2, lon2):
    lat1 = float(lat1)
    lon1 = float(lon1)
    lat2 = float(lat2)
    lon2 = float(lon2)
    R = 6371e3
    X = lat1 * np.pi/180
    Y = lat2 * np.pi/180
    M = (lat2-lat1) * np.pi/180
    N = (lon2-lon1) * np.pi/180
    a = np.sin(M/2) * np.sin(M/2) + np.cos(X) * np.cos(Y) * np.sin(N/2) * np.sin(N/2) 
    c = 2 * np.arctan2(np.sqrt(a), np.sqrt(1-a))
    d = R * c
    return d
    
def home(request):
    return render(request, "home.html")

def select_login(request):
    return render(request, "select_login.html")

def login_customer(request):
    if request.method == "POST":
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()

            if user.type == User.Types.CUSTOMER:
                login(request, user)
                try:
                    user = User.objects.get(username=request.user.username)
                    customer = Customer.objects.get(user=user)
                except Customer.DoesNotExist:
                    messages.error(request, 'You are not customer')
                    return redirect('home')
                

                record = {'time':str(pd.Timestamp.now())[:19], 'user_id':user.username, 
                          'operation':operations.LOGIN.value, 'payment':np.nan, 
                          'vehicle_id':np.nan, 'lat':np.nan, 'lon':np.nan, 'location':"", 
                          'battery_level':np.nan, 'vehicle_charge':np.nan, 'charge':np.nan}
                write_record(record_type.CUSTOMER, record)

                return redirect("after_login_customer")
            else:
                messages.error(request, "Not authorized to log in as a Customer.")
        else:
            form.errors.clear()
            messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()
    
    return render(request, "login_customer.html", {"form": form})

def login_operator(request):
    if request.method == "POST":
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            if user.type == User.Types.OPERATOR:
                login(request, user)
                record = {'time':str(pd.Timestamp.now())[:19], 'user_id':user.username, 
                          'operation':operations.LOGIN.value, 'vehicle_id':np.nan, 
                          'lat':np.nan, 'lon':np.nan, 'location':"", 'battery_level':np.nan}
                write_record(record_type.OPERATOR, record)
                return redirect("after_login_operator")
            else:
                messages.error(request, "Not authorized to log in as a Operator.")
        else:
            form.errors.clear()
            messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()
    
    return render(request, "login_operator.html", {"form": form})

def login_manager(request):
    if request.method == "POST":
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            if user.type == User.Types.MANAGER:
                login(request, user)
                return redirect("after_login_manager")
            else:
                messages.error(request, "Not authorized to log in as a Manager.")
        else:
             form.errors.clear()
             messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()
    
    return render(request, "login_manager.html", {"form": form})

def signup_func(request):
    if request.method == "POST":
        form = SignupForm(request.POST)
        if form.is_valid():
            user = form.save()
            lat = np.random.uniform(lat_max, lat_min)
            lon = np.random.uniform(lon_max, lon_min)
            Customer.objects.create(
                user=user, 
                is_using_vehicle=False,
                start_using_time=None,
                end_using_time=None,
                lat=lat,
                lon=lon,
            )

            # this is only for customer sign up
            record = {'time':str(pd.Timestamp.now())[:19], 'user_id':user.username, 
                        'operation':operations.CREATE.value, 'payment':np.nan, 
                        'vehicle_id':np.nan, 'lat':np.nan, 'lon':np.nan, 'location':"",
                        'battery_level':np.nan, 'vehicle_charge':np.nan, 'charge':np.nan}
            write_record(record_type.CUSTOMER, record)
            form.errors.clear()

            messages.success(request, "Account create successfully")
            return redirect("select_login")
    else:
        form = SignupForm()
    return render(request, "signup.html", {"form": form})

def logout_func(request):
    if request.method == "POST":
        logout(request)
        return redirect("home")

@login_required
def after_login_customer(request):
    try:
        user = User.objects.get(username=request.user.username)
        customer = Customer.objects.get(user=user)
        vehicles = Vehicle.objects.all()
        customers = [customer]
    except Customer.DoesNotExist:
        messages.error(request, 'You are not customer')
        return redirect('home')
    return render(request, "after_login_customer.html", {"customer": customer,"customers": customers,"vehicles": vehicles})
    
@login_required
def after_login_operator(request):
    try:
        user = User.objects.get(username=request.user.username)
        operator = Operator.objects.get(user=user)
        vehicles = Vehicle.objects.all()
        customers = Customer.objects.all()
    except Operator.DoesNotExist:
        messages.error(request, 'You are not operator')
        return redirect('home')
    return render(request, "after_login_operator.html", {"customers": customers,"vehicles": vehicles})
    
@login_required
def after_login_manager(request):
    try:
        user = User.objects.get(username=request.user.username)
        manager = Manager.objects.get(user=user)
    except Manager.DoesNotExist:
        messages.error(request, 'You are not manager')
        return redirect('home')

    total_bikes = Vehicle.objects.filter(vehicle_type=Vehicle.VEHICLE_TYPES.BIKE).count()
    available_bikes = Vehicle.objects.filter(vehicle_type=Vehicle.VEHICLE_TYPES.BIKE, status_type=Vehicle.STATUS_TYPES.NOT_USING).count()
    defective_bikes = Vehicle.objects.filter(vehicle_type=Vehicle.VEHICLE_TYPES.BIKE, status_type=Vehicle.STATUS_TYPES.DEFECTIVE).count()

    total_scooters = Vehicle.objects.filter(vehicle_type=Vehicle.VEHICLE_TYPES.SCOOTER).count()
    available_scooters = Vehicle.objects.filter(vehicle_type=Vehicle.VEHICLE_TYPES.SCOOTER, status_type=Vehicle.STATUS_TYPES.NOT_USING).count()
    defective_scooters = Vehicle.objects.filter(vehicle_type=Vehicle.VEHICLE_TYPES.SCOOTER, status_type=Vehicle.STATUS_TYPES.DEFECTIVE).count()

    vehicles = Vehicle.objects.all()
    customers = Customer.objects.all()
    return render(request, 'after_login_manager.html', {
        'total_bikes': total_bikes,
        'available_bikes': available_bikes,
        'defective_bikes': defective_bikes,
        'total_scooters': total_scooters,
        'available_scooters': available_scooters,
        'defective_scooters': defective_scooters,
        'vehicles': vehicles,
        'customers': customers
    })

@login_required
def after_login_customer_rent(request):
    vehicles = Vehicle.objects.all()
    vehiclesall = Vehicle.objects.filter(status_type=Vehicle.STATUS_TYPES.NOT_USING)
    if request.method == "POST":
        form = RentVehicleForm(data=request.POST)
        try:
            if form.is_valid():
                vehicle_id = form.cleaned_data['id']
                try:
                    user = User.objects.get(username=request.user.username)
                    customer = Customer.objects.get(user=user)
                except Customer.DoesNotExist:
                    messages.error(request, 'You are not customer')
                    return redirect('home')
                
                vehicle = Vehicle.objects.get(id=vehicle_id)

                if user.type != User.Types.CUSTOMER:
                    messages.error(request, "You are not authorized to log in as a Customer.")
                elif vehicle.status_type != Vehicle.STATUS_TYPES.NOT_USING:
                    messages.error(request, "This vehicle is not available right now.")
                elif customer.charge < 0:
                    messages.error(request, "You need to pay previous charges.")
                elif vehicle.battery_level <= 0:
                    messages.error(request, "Vehicle need charge.")
                else:
                    customer.is_using_vehicle = True
                    customer.vehicle = vehicle
                    customer.start_using_time = int(timezone.now().timestamp())
                    customer.save()

                    vehicle.is_in_use = True
                    vehicle.customer = user
                    vehicle.status_type = Vehicle.STATUS_TYPES.USING
                    vehicle.save()

                    record = {'time': str(pd.Timestamp.now())[:19], 'user_id': user.username,
                                'operation': operations.RENT.value, 'payment': np.nan,
                                'vehicle_id': vehicle.id, 'lat': vehicle.lat, 'lon': vehicle.lon,'location':vehicle.location,
                                'battery_level': vehicle.battery_level, 'vehicle_charge': np.nan, 'charge': customer.charge}
                    write_record(record_type.CUSTOMER, record)

                    record = {'time': str(pd.Timestamp.now())[:19], 'vehicle_id': vehicle.id,
                                'lat': vehicle.lat, 'lon': vehicle.lon, 'location':vehicle.location, 'battery_level': vehicle.battery_level,
                                'vehicle_type': vehicle.vehicle_type, 'status_type': vehicle.status_type}
                    write_record(record_type.VEHICLE, record)

                    messages.success(request, "Vehicle rent successfully")
                    return redirect("after_login_customer")
        except Vehicle.DoesNotExist:                
            messages.error(request, "Vehicle not found.")
    else:
        form = RentVehicleForm()

    try:
        user = User.objects.get(username=request.user.username)
        customer = Customer.objects.get(user=user)
        vehicles_ = []
        for vehicle in vehicles:
            if cal_dis(customer.lat, customer.lon, vehicle.lat, vehicle.lon) <= Decimal(distance) and vehicle.status_type == Vehicle.STATUS_TYPES.NOT_USING and vehicle.battery_level > 0:
                vehicles_.append(vehicle)
        vehicles = vehicles_
    except Exception as e:
        print(e)
        vehicles = []
    return render(request, "after_login_customer_rent.html", {"form": form, "vehicles": vehicles,"vehiclesall":vehiclesall})

@login_required
def after_login_customer_return(request):
    if request.method == "POST":
        try:
            try:
                user = User.objects.get(username=request.user.username)
                customer = Customer.objects.get(user=user)
            except Customer.DoesNotExist:
                messages.error(request, 'You are not customer')
                return redirect('home')
            if customer.is_using_vehicle:
                vehicle = customer.vehicle
                if vehicle:
                    vehicle.is_in_use = False
                    vehicle.customer = None
                    vehicle.status_type = Vehicle.STATUS_TYPES.NOT_USING
                    customer.end_using_time = int(timezone.now().timestamp())
                    battery_loss = vehicle.battery_level - max(1, int(np.round((customer.end_using_time - customer.start_using_time)/battery_loss_frequency_in_sec)))
                    battery_loss = max(0, battery_loss)
                    vehicle.battery_level = battery_loss

                    customer.is_using_vehicle = False
                    
                    vehicle_charge = int(round((customer.end_using_time - customer.start_using_time) * charge_per_sec, 2))
                    customer.charge -= vehicle_charge
                    customer.vehicle = None

                    lat = Decimal(np.random.uniform(lat_max, lat_min))
                    lon = Decimal(np.random.uniform(lon_max, lon_min))
                    location = get_address(lat, lon)

                    vehicle.lat = lat
                    vehicle.lon = lon
                    customer.lat = lat
                    customer.lon = lon
                    vehicle.location = location
                    vehicle.save()

                    customer.save()

                    record = {'time': str(pd.Timestamp.now())[:19], 'user_id': user.username,
                                'operation': operations.RETURN.value, 'payment': np.nan,
                                'vehicle_id': vehicle.id, 'lat': vehicle.lat, 'lon': vehicle.lon,'location':vehicle.location,
                                'battery_level': vehicle.battery_level, 'vehicle_charge': vehicle_charge, 'charge': customer.charge}
                    write_record(record_type.CUSTOMER, record)

                    record = {'time': str(pd.Timestamp.now())[:19], 'vehicle_id': vehicle.id,
                                'lat': vehicle.lat, 'lon': vehicle.lon, 'location':vehicle.location, 'battery_level': vehicle.battery_level,
                                'vehicle_type': vehicle.vehicle_type, 'status_type': vehicle.status_type}
                    write_record(record_type.VEHICLE, record)

                    messages.success(request, "Vehicle return successfully")
                    return redirect("after_login_customer")
        except:
            messages.error(request, "Vehicle not found.")
    return render(request, 'after_login_customer_return.html',)

def after_login_customer_report(request):
    vehicles = Vehicle.objects.all()
    if request.method == "POST":
        form = ReportVehicleForm(data=request.POST)
        try:
            if form.is_valid():
                vehicle_id = form.cleaned_data['id']
                try:
                    user = User.objects.get(username=request.user.username)
                    customer = Customer.objects.get(user=user)
                except Customer.DoesNotExist:
                    messages.error(request, 'You are not customer')
                    return redirect('home')
                vehicle = Vehicle.objects.get(id=vehicle_id)

                if vehicle.status_type == Vehicle.STATUS_TYPES.USING:
                    messages.error(request, "This vehicle is still been using.")

                elif vehicle.status_type == Vehicle.STATUS_TYPES.DEFECTIVE:
                    messages.error(request, "This vechicle is already reported.")
                else:
                    vehicle.status_type = Vehicle.STATUS_TYPES.DEFECTIVE
                    vehicle.save()

                    record = {'time': str(pd.Timestamp.now())[:19], 'user_id': user.username,
                                'operation': operations.REPORT.value, 'payment': np.nan,
                                'vehicle_id': vehicle.id, 'lat': vehicle.lat, 'lon': vehicle.lon,'location':vehicle.location,
                                'battery_level': vehicle.battery_level, 'vehicle_charge': np.nan, 'charge': customer.charge}
                    write_record(record_type.CUSTOMER, record)

                    record = {'time': str(pd.Timestamp.now())[:19], 'vehicle_id': vehicle.id,
                                'lat': vehicle.lat, 'lon': vehicle.lon, 'location':vehicle.location, 'battery_level': vehicle.battery_level,
                                'vehicle_type': vehicle.vehicle_type, 'status_type': vehicle.status_type}
                    write_record(record_type.VEHICLE, record)

                    messages.success(request, "Vehicle report successfully")
                    return redirect("after_login_customer")
        except:
            messages.error(request, "Vehicle not found.")
    else:
        form = ReportVehicleForm()
    return render(request, 'after_login_customer_report.html', {'form': form, 'vehicles': vehicles})

def after_login_customer_pay(request):
    if request.method == "POST":
        form = PaymentForm(request.POST)
        try:
            if form.is_valid():
                payment_amount = form.cleaned_data['amount']
                try:
                    user = User.objects.get(username=request.user.username)
                    customer = Customer.objects.get(user=user)
                except Customer.DoesNotExist:
                    messages.error(request, 'You are not customer')
                    return redirect('home')
                
                if payment_amount <= 0:
                    messages.error(request, 'The payment amount must be greater than 0.')
                else:
                    customer.charge += payment_amount
                    customer.save()

                    record = {'time': str(pd.Timestamp.now())[:19], 'user_id': user.username,
                                'operation': operations.REPORT.value, 'payment': payment_amount,
                                'vehicle_id': np.nan, 'lat': np.nan, 'lon': np.nan,'location':"",
                                'battery_level': np.nan, 'vehicle_charge': np.nan, 'charge': customer.charge}
                    write_record(record_type.CUSTOMER, record)

                    messages.success(request, "Vehicle return successfully")
                    return redirect("after_login_customer")
        except:
            messages.error(request, "Payment invalid.")
    else:
        form = PaymentForm()

    return render(request, 'after_login_customer_pay.html', {'form': form})

# Operator: Track all vehicles
@login_required
def after_login_operator_track(request):
    if request.method == "GET":
        try:
            user = User.objects.get(username=request.user.username)
            operator = Operator.objects.get(user=user)
        except Operator.DoesNotExist:
            messages.error(request, 'You are not Operator')
            return redirect('home')
        try:
            vehicles = Vehicle.objects.all()
            record = {'time':str(pd.Timestamp.now())[:19], 'user_id':user.username, 
                    'operation':operations.TRACK.value, 'vehicle_id':np.nan, 
                    'lat':np.nan, 'lon':np.nan,'location':"", 'battery_level':np.nan}
            write_record(record_type.OPERATOR, record)
            return render(request, 'after_login_operator_track.html', {'vehicles': vehicles})
        except:
            messages.error(request, 'Invalid request')  
            return render(request, 'after_login_operator.html')

# Operator: Charge a vehicle when battery is depleted
@login_required
def after_login_operator_charge(request):
    vehicles = Vehicle.objects.all()
    if request.method == "POST":
        form = ChargeVehicleForm(data=request.POST)
        try:
            if form.is_valid():
                vehicle_id = form.cleaned_data['id']
                try:
                    user = User.objects.get(username=request.user.username)
                    operator = Operator.objects.get(user=user)
                except Operator.DoesNotExist:
                    messages.error(request, 'You are not Operator')
                    return redirect('home')
                vehicle = Vehicle.objects.get(id=vehicle_id)

                if vehicle.status_type == Vehicle.STATUS_TYPES.USING:
                    messages.error(request, "This vehicle is still been using.")

                elif vehicle.status_type == Vehicle.STATUS_TYPES.DEFECTIVE:
                    messages.error(request, "This vechicle is already defective.")
                elif vehicle.battery_level >= 100:
                    messages.error(request, "This vechicle is already fully charged.")
                else:
                    vehicle.battery_level = 100
                    vehicle.save()

                    record = {'time':str(pd.Timestamp.now())[:19], 'user_id':user.username, 
                            'operation':operations.CHARGE.value, 'vehicle_id':vehicle.id, 
                            'lat':vehicle.lat, 'lon':vehicle.lon,'location':vehicle.location, 'battery_level':vehicle.battery_level}
                    write_record(record_type.OPERATOR, record)

                    record = {'time': str(pd.Timestamp.now())[:19], 'vehicle_id': vehicle.id,
                                'lat': vehicle.lat, 'lon': vehicle.lon,'location':vehicle.location, 'battery_level': vehicle.battery_level,
                                'vehicle_type': vehicle.vehicle_type, 'status_type': vehicle.status_type}
                    write_record(record_type.VEHICLE, record)

                    messages.success(request, "Vehicle charge successfully")
                    return redirect("after_login_operator")
        except:
            messages.error(request, "Vehicle not found.")
    else:
        form = ChargeVehicleForm()
    return render(request, 'after_login_operator_charge.html', {'form': form, 'vehicles': vehicles})
    
# Operator: Repair a defective vehicle
@login_required
def after_login_operator_repair(request):
    vehicles = Vehicle.objects.all()
    if request.method == "POST":
        form = RepairVehicleForm(data=request.POST)
        try:
            if form.is_valid():
                vehicle_id = form.cleaned_data['id']
                try:
                    user = User.objects.get(username=request.user.username)
                    operator = Operator.objects.get(user=user)
                except Operator.DoesNotExist:
                    messages.error(request, 'You are not Operator')
                    return redirect('home')
                vehicle = Vehicle.objects.get(id=vehicle_id)

                if vehicle.status_type != Vehicle.STATUS_TYPES.DEFECTIVE:
                    messages.error(request, "This vechicle is not defective.")
                else:
                    vehicle.status_type = Vehicle.STATUS_TYPES.NOT_USING
                    vehicle.save()

                    record = {'time':str(pd.Timestamp.now())[:19], 'user_id':user.username, 
                            'operation':operations.REPAIR.value, 'vehicle_id':vehicle.id, 
                            'lat':vehicle.lat, 'lon':vehicle.lon,'location':vehicle.location, 'battery_level':vehicle.battery_level}
                    write_record(record_type.OPERATOR, record)

                    record = {'time': str(pd.Timestamp.now())[:19], 'vehicle_id': vehicle.id,
                                'lat': vehicle.lat, 'lon': vehicle.lon,'location':vehicle.location, 'battery_level': vehicle.battery_level,
                                'vehicle_type': vehicle.vehicle_type, 'status_type': vehicle.status_type}
                    write_record(record_type.VEHICLE, record)

                    messages.success(request, "Vehicle repair successfully")
                    return redirect("after_login_operator")
        except:
            messages.error(request, "Vehicle not found.")
    else:
        form = RepairVehicleForm()
    return render(request, 'after_login_operator_repair.html', {'form': form, 'vehicles': vehicles})

# 4. Move a vehicle to a new location
@login_required
def after_login_operator_move(request):
    vehicles = Vehicle.objects.all()
    if request.method == "POST":
        form = MoveVehicleForm(data=request.POST)
        try:
            if form.is_valid():
                vehicle_id = form.cleaned_data['id']
                lat = form.cleaned_data['lat']
                lon = form.cleaned_data['lon']
                try:
                    user = User.objects.get(username=request.user.username)
                    operator = Operator.objects.get(user=user)
                except Operator.DoesNotExist:
                    messages.error(request, 'You are not Operator')
                    return redirect('home')
                vehicle = Vehicle.objects.get(id=vehicle_id)

                if vehicle.status_type == Vehicle.STATUS_TYPES.USING:
                    messages.error(request, "This vechicle is using.")
                if lat > lat_max or lat < lat_min or lon > lon_max or lon < lon_min:
                        messages.error(request, "This coordinate is outside the city. ")
                        messages.error(request, f"Latitude should be between {lat_min} and {lat_max}, and longitude should be between {lon_min} and {lon_max}.")
                else:
                    vehicle.lat = Decimal(round(lat, 5))
                    vehicle.lon = Decimal(round(lon, 5))
                    vehicle.location = get_address(lat, lon)
                    vehicle.save()

                    record = {'time':str(pd.Timestamp.now())[:19], 'user_id':user.username, 
                            'operation':operations.MOVE.value, 'vehicle_id':vehicle.id, 
                            'lat':vehicle.lat, 'lon':vehicle.lon,'location':vehicle.location, 'battery_level':vehicle.battery_level}
                    write_record(record_type.OPERATOR, record)

                    record = {'time': str(pd.Timestamp.now())[:19], 'vehicle_id': vehicle.id,
                                'lat': vehicle.lat, 'lon': vehicle.lon,'location':vehicle.location, 'battery_level': vehicle.battery_level,
                                'vehicle_type': vehicle.vehicle_type, 'status_type': vehicle.status_type}
                    write_record(record_type.VEHICLE, record)

                    messages.success(request, "Vehicle move successfully")
                    return redirect("after_login_operator")
        except:
            messages.error(request, "Vehicle not found.")
    else:
        form = MoveVehicleForm()
    return render(request, 'after_login_operator_move.html', {'form': form, 'vehicles': vehicles})


@login_required
def after_login_manager_generate_reports(request):
    if request.method == "POST":
        form = GenerateReportForm(data=request.POST)
        try:
            # 设置字体
            font = {'size': 12}
            matplotlib.rc('font', **font)

            plt.figure(figsize=(10, 50))
            if form.is_valid():
                start_time = form.cleaned_data['start_time']
                end_time = form.cleaned_data['end_time']
                try:
                    user = User.objects.get(username=request.user.username)
                    manager = Manager.objects.get(user=user)
                except Manager.DoesNotExist:
                    messages.error(request, 'You are not Manager')
                    return redirect('home')
                vehicles = Vehicle.objects.all()
                if start_time >= end_time:
                    messages.error(request, "Start time cannot greater equal than end time.")
                else:
                    try:
                        customer_record = get_record(record_type.CUSTOMER.value)
                        operator_record = get_record(record_type.OPERATOR.value)
                        vehicle_record = get_record(record_type.VEHICLE.value)
                        customer_record['time'] = pd.to_datetime(customer_record['time'])
                        operator_record['time'] = pd.to_datetime(operator_record['time'])
                        vehicle_record['time'] = pd.to_datetime(vehicle_record['time'])
                        start_time = pd.to_datetime(start_time).tz_localize(None)
                        end_time = pd.to_datetime(end_time).tz_localize(None)
                        select_customer_record = customer_record[(customer_record.time >= start_time)&(customer_record.time <= end_time)]
                        select_operator_record = operator_record[(operator_record.time >= start_time)&(operator_record.time <= end_time)]
                        select_vehicle_record = vehicle_record[(vehicle_record.time >= start_time)&(vehicle_record.time <= end_time)]

                        select_customer_record['count'] = 1
                        select_operator_record['count'] = 1
                        select_vehicle_record['count'] = 1

                        select_customer_record['minute'] = pd.to_datetime(select_customer_record.time.astype(str).str[:16])
                        select_operator_record['minute'] = pd.to_datetime(select_operator_record.time.astype(str).str[:16])
                        select_vehicle_record['minute'] = pd.to_datetime(select_vehicle_record.time.astype(str).str[:16])

                        select_customer_record['hour'] = select_customer_record['time'].dt.hour
                        select_operator_record['hour'] = select_operator_record['time'].dt.hour
                        select_vehicle_record['hour'] = select_vehicle_record['time'].dt.hour

                        try:
                            font = {'size': 12}
                            matplotlib.rc('font', **font)

                            plt.figure(figsize=(10, 60))

                            # line show login activity
                            temp_df = pd.merge(select_customer_record, select_operator_record,
                                               on=['time', 'operation', 'minute'], how='outer')
                            temp_df['count'] = temp_df['count_x'] + temp_df['count_y']
                            select_operation = 'login'
                            plt.subplot(8, 1, 1)
                            plt.plot(
                                select_customer_record[select_customer_record['operation'] == select_operation].groupby(
                                    'minute')['count'].sum().index,
                                select_customer_record[select_customer_record['operation'] == select_operation].groupby(
                                    'minute')['count'].sum(), label="customer_login", linewidth=10
                            )
                            plt.plot(
                                select_operator_record[select_operator_record['operation'] == select_operation].groupby(
                                    'minute')['count'].sum().index,
                                select_operator_record[select_operator_record['operation'] == select_operation].groupby(
                                    'minute')['count'].sum(), label="operator_login", linewidth=10
                            )
                            plt.title(f'Login activity during {str(start_time)[:-3]} - {str(end_time)[:-3]}')
                            plt.ylabel('Times')
                            plt.legend()

                            # line show rent and return activity
                            plt.subplot(8, 1, 2)
                            plt.plot(
                                select_customer_record[select_customer_record['operation'] == 'rent'].groupby('minute')[
                                    'count'].sum().index,
                                select_customer_record[select_customer_record['operation'] == 'rent'].groupby('minute')[
                                    'count'].sum(), label="rent", linewidth=10
                            )
                            plt.plot(
                                select_customer_record[select_customer_record['operation'] == 'return'].groupby(
                                    'minute')['count'].sum().index,
                                select_customer_record[select_customer_record['operation'] == 'return'].groupby(
                                    'minute')['count'].sum(), label="return", linewidth=10
                            )
                            plt.title(f'Rent and return activity during {str(start_time)[:-3]} - {str(end_time)[:-3]}')
                            plt.ylabel('Times')
                            plt.legend()

                            # plot show customer operations in minute resolution
                            plt.subplot(8, 1, 3)
                            for each in ['create', 'login', 'rent', 'return', 'report', 'charge']:
                                plt.plot(
                                    select_customer_record[select_customer_record['operation'] == each].groupby(
                                        'minute')['count'].sum().index,
                                    select_customer_record[select_customer_record['operation'] == each].groupby(
                                        'minute')['count'].sum(), label=each, linewidth=10
                                )
                            plt.title(f'Customer activity during {str(start_time)[:-3]} - {str(end_time)[:-3]}')
                            plt.ylabel('Times')
                            plt.legend()

                            # plot show operator operations in minute resolution
                            plt.subplot(8, 1, 4)
                            for each in ['create', 'login', 'track', 'charge', 'repair', 'move']:
                                plt.plot(
                                    select_operator_record[select_operator_record['operation'] == each].groupby(
                                        'minute')['count'].sum().index,
                                    select_operator_record[select_operator_record['operation'] == each].groupby(
                                        'minute')['count'].sum(), label=each, linewidth=10
                                )
                            plt.title(f'Operator activity during {str(start_time)[:-3]} - {str(end_time)[:-3]}')
                            plt.ylabel('Times')
                            plt.legend()

                            # scatter show customer correlation between pay and other in coords
                            plt.subplot(8, 1, 5)
                            plt.scatter(
                                select_customer_record[select_customer_record['operation'] == 'rent']['charge'],
                                select_customer_record[select_customer_record['operation'] == 'rent']['operation'],
                                s=100
                            )
                            plt.scatter(
                                select_customer_record[select_customer_record['operation'] == 'return']['charge'],
                                select_customer_record[select_customer_record['operation'] == 'return']['operation'],
                                s=100
                            )
                            plt.scatter(
                                select_customer_record[select_customer_record['operation'] == 'charge']['charge'],
                                select_customer_record[select_customer_record['operation'] == 'charge']['operation'],
                                s=100
                            )
                            plt.title(
                                f'Customer balance after rent, return, and pay during {str(start_time)[:-3]} - {str(end_time)[:-3]}')
                            plt.xlabel('Balance')
                            plt.legend(['rent', 'return', 'pay'])

                            # line show each vehicle activity
                            plt.subplot(8, 1, 6)
                            for each in vehicles:
                                plt.plot(
                                    select_vehicle_record[select_vehicle_record['vehicle_id'] == each.id]['minute'],
                                    select_vehicle_record[select_vehicle_record['vehicle_id'] == each.id][
                                        'status_type'], label=each, linewidth=10
                                )
                            plt.title(f'Each vehicle activity during {str(start_time)[:-3]} - {str(end_time)[:-3]}')

                            # scatter show vehicle activity in coords
                            plt.subplot(8, 1, 7)
                            plt.scatter(
                                select_customer_record[select_customer_record['operation'] == 'rent']['lat'],
                                select_customer_record[select_customer_record['operation'] == 'rent']['lon'], s=100
                            )
                            plt.scatter(
                                select_customer_record[select_customer_record['operation'] == 'return']['lat'],
                                select_customer_record[select_customer_record['operation'] == 'return']['lon'], s=100
                            )
                            plt.title(
                                f'Rent and return activity in coordinates during {str(start_time)[:-3]} - {str(end_time)[:-3]}')
                            plt.xlabel('Lon')
                            plt.ylabel('Lat')
                            plt.legend(['rent', 'return'])

                            # scatter show operator charge activity in hour
                            bar_width = 0.4
                            plt.subplot(8, 1, 8)
                            temp = pd.merge(select_operator_record,
                                            select_vehicle_record[['vehicle_id', 'vehicle_type']], on='vehicle_id')
                            plt.bar(
                                temp[(temp['operation'] == 'charge') & (temp['vehicle_type'] == 'BIKE')].groupby(
                                    temp['hour'])['count'].sum().index,
                                temp[(temp['operation'] == 'charge') & (temp['vehicle_type'] == 'BIKE')].groupby(
                                    temp['hour'])['count'].sum().values, width=bar_width
                            )
                            plt.bar(
                                temp[(temp['operation'] == 'charge') & (temp['vehicle_type'] == 'SCOOTER')].groupby(
                                    temp['hour'])['count'].sum().index + bar_width,
                                temp[(temp['operation'] == 'charge') & (temp['vehicle_type'] == 'SCOOTER')].groupby(
                                    temp['hour'])['count'].sum().values, width=bar_width
                            )
                            plt.xticks(np.arange(24))
                            plt.title(f'Operator charge activity in hour during {str(start_time)[:-3]} - {str(end_time)[:-3]}')
                            plt.ylabel('Times')
                            plt.ylabel('Hour')
                            plt.legend(['Bike', 'Scooter'])

                            plt.savefig(os.path.join(static_path, 'report.jpg'))
                            plt.close()

                            return redirect('after_login_manager_show_reports')

                        except Exception as e:
                            print(f"Error during report generation: {e}")
                            messages.error(request, 'Generate report fail')
                    except:
                        messages.error(request, 'Record reading fail')

        except:
            messages.error(request, 'Generate report fail')
    else:
        form = GenerateReportForm()
    return render(request, 'after_login_manager_generate_reports.html', {'form': form})

@login_required
def after_login_manager_show_reports(request):
    return render(request, 'after_login_manager_show_reports.html')

@login_required
def after_login_manager_signup_operator(request):
    if request.method == "POST":
        form = SignupForm(request.POST)
        if form.is_valid():
            # print(form.cleaned_data['username'])
            # print(form.cleaned_data['password1'])
            # print(form.cleaned_data['password2'])
            user, created_user = User.objects.get_or_create(
                username=form.cleaned_data['username'],
                defaults={
                    'password': form.cleaned_data['password1'], 
                    'type': User.Types.OPERATOR
                }
            )
            if created_user:
                user.set_password('password123')
                user.save()
            operator_instance, created_operator = Operator.objects.get_or_create(
                user=user,
                defaults={
                }
            )
            # this is only for customer sign up
            record = {'time':str(pd.Timestamp.now())[:19], 'user_id':user.username, 
                        'operation':operations.CREATE.value, 'payment':np.nan, 
                        'vehicle_id':np.nan, 'lat':np.nan, 'lon':np.nan, 'location':"",
                        'battery_level':np.nan, 'vehicle_charge':np.nan, 'charge':np.nan}
            write_record(record_type.OPERATOR, record)
            form.errors.clear()
            messages.success(request, f"Operator {operator_instance.user.username} create successful")
            return redirect("after_login_manager")
    else:

        form = SignupForm()
    return render(request, "after_login_manager_signup_operator.html", {"form": form})

@login_required
def after_login_manager_user_info(request):
    if request.method == "GET":
        try:
            user = User.objects.get(username=request.user.username)
            manager = Manager.objects.get(user=user)
        except Operator.DoesNotExist:
            messages.error(request, 'You are not Operator')
            return redirect('home')
        try:
            customers = Customer.objects.all()
            operators = Vehicle.objects.all()
            record = {'time':str(pd.Timestamp.now())[:19], 'user_id':user.username, 
                    'operation':operations.TRACK.value, 'vehicle_id':np.nan, 
                    'lat':np.nan, 'lon':np.nan,'location':"", 'battery_level':np.nan}
            write_record(record_type.OPERATOR, record)

            return render(request, 'after_login_manager_user_info.html', {'customers': customers, 'operators': operators})
        except:
            messages.error(request, 'Invalid request')  
            return render(request, 'after_login_manager.html')