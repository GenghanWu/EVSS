from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import User


class SignupForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'password1', 'password2']

    def save(self, commit=True):
        user = super().save(commit=False)
        user.type = User.Types.CUSTOMER 
        if commit:
            user.save()
        return user
    
class RentVehicleForm(forms.Form):
    id = forms.CharField(label="Vehicle ID", max_length=15, required=True)

class ReportVehicleForm(forms.Form):
    id = forms.CharField(label="Vehicle ID", max_length=15, required=True)

class PaymentForm(forms.Form):
    amount = forms.DecimalField(
        max_digits=10,
        decimal_places=2,
        required=True,
        label='Amount'
    )

class ChargeVehicleForm(forms.Form):
    id = forms.CharField(label="Vehicle ID", max_length=15, required=True)

class RepairVehicleForm(forms.Form):
    id = forms.CharField(label="Vehicle ID", max_length=15, required=True)

class MoveVehicleForm(forms.Form):
    id = forms.CharField(label="Vehicle ID", max_length=15, required=True)
    
    lat = forms.DecimalField(
        max_digits=10,
        decimal_places=5,
        required=True,
        label='Latitude'
    )
    lon = forms.DecimalField(
        max_digits=10,
        decimal_places=5,
        required=True,
        label='Longitude'
    )

class GenerateReportForm(forms.Form):
    start_time = forms.DateTimeField(
        widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        label='Report Start Time'
    )
    end_time = forms.DateTimeField(
        widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        label='Report End Time'
    )