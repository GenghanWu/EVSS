# python manage.py makemigrations
# python manage.py migrate
# python manage.py createsuperuser
from django.db import models
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.hashers import make_password
from decimal import Decimal
# Create your models here.

class User(AbstractUser):
    class Types(models.TextChoices):
        CUSTOMER = "CUSTOMER", "Customer"
        OPERATOR = "OPERATOR", "Operator"
        MANAGER = "MANAGER", "Manager"
        
    type = models.CharField(
        max_length=50,
        choices=Types.choices,
        default=Types.CUSTOMER
    )

    def save(self, *args, **kwargs):
        if not self.pk and self.type is None:
            self.type = self.Types.CUSTOMER
        super().save(*args, **kwargs)

class Customer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    password = models.CharField(max_length=128)
    start_using_time = models.BigIntegerField(null=True, blank=True)  # timestamp
    end_using_time = models.BigIntegerField(null=True, blank=True)
    is_using_vehicle = models.BooleanField(default=False)
    vehicle = models.ForeignKey('Vehicle', on_delete=models.SET_NULL, null=True, blank=True, related_name="current_customer")
    charge = models.DecimalField(max_digits=10, decimal_places=2, default=0.0)

    def save(self, *args, **kwargs):
        if self.password:
            self.password = make_password(self.password)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.user.username
    
    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['is_using_vehicle', 'vehicle'], name='unique_customer_use_per_vehicle')
        ]


class Operator(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    password = models.CharField(max_length=128)
    department = models.CharField(max_length=100, null=True, blank=True)
    
    def save(self, *args, **kwargs):
        if self.password:
            self.password = make_password(self.password)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.user.username

class Manager(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    password = models.CharField(max_length=128)
    department = models.CharField(max_length=100, null=True, blank=True)

    def save(self, *args, **kwargs):
        if self.password:
            self.password = make_password(self.password)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.user.username
    
class Vehicle(models.Model):
    id = models.AutoField(primary_key=True)
    customer = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="vehicles")
    battery_level = models.IntegerField(default=100)
    lat = models.DecimalField(max_digits=10, decimal_places=5, default=0.0)
    lon = models.DecimalField(max_digits=10, decimal_places=5, default=0.0)
    location = models.CharField(max_length=255, default="")
    is_in_use = models.BooleanField(default=False)

    class VEHICLE_TYPES(models.TextChoices):
        SCOOTER = 'SCOOTER', 'Electric Scooter'
        BIKE = 'BIKE', 'Electric Bike'
    
    vehicle_type = models.CharField(
        max_length=50,
        choices=VEHICLE_TYPES.choices,
        default=VEHICLE_TYPES.BIKE
    )

    vehicle_type = models.CharField(max_length=50, choices=VEHICLE_TYPES.choices, default=VEHICLE_TYPES.BIKE)

    class STATUS_TYPES(models.TextChoices):
        USING = 'USING', 'Using'
        NOT_USING = 'NOT_USING', 'Not_using'
        DEFECTIVE = 'DEFECTIVE', 'Defective'

    status_type = models.CharField(
        max_length=50,
        choices=STATUS_TYPES.choices,
        default=STATUS_TYPES.NOT_USING
    )

    status_type = models.CharField(max_length=50, choices=STATUS_TYPES.choices, default=STATUS_TYPES.NOT_USING)

    def save(self, *args, **kwargs):
        if not self.pk and self.status_type is None:
            self.status_type = self.STATUS_TYPES.NOT_USING
        if not self.pk and self.vehicle_type is None:
            self.vehicle_type = self.VEHICLE_TYPES.BIKE
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Vehicle {self.id} - {self.status_type}"
    
    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['is_in_use', 'customer'], name='unique_vehicle_use_per_customer')
        ]
