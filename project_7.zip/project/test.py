import sqlite3

# update
# cursor.execute('''UPDATE Vehicle SET ... = ? WHERE id = ?''', (..., id))

# User table
## Unique User_ID, Password, User_type, Renting_starting_time, Renting_ending_time, Charge

# Vehicle table
## Unique Vehicle_ID, Charging_points, City_locations, Customer_id, Status

# Customers
## Rent(vehicle_ID, user_ID)
### check Charge <= 0, user_ID, Renting_starting_time = now,
### 

## Return
### 

## Report a vehicle
### 

## Pay(amount)
### 

# Operators
## Track
###

## Charge
###

## Repair
### 

## Move vehicles
### 


# Managers
## Generate reports
### plt.plot(), Select * from ...

## Delete data
###

con = sqlite3.connect('db.sqlite3')
cursor = con.cursor()


cursor.execute("""CREATE TABLE IF NOT EXIST User(
	User_ID integer PRIMARY KEY, 
	User_type text NOT NULL, 
	Renting_starting_time integer NOT NULL, 
	Renting_ending_time integer NOT NULL,
	Charge integer NOT NULL,);""")

cursor.execute("""CREATE TABLE IF NOT EXIST Vehicle(
	Vehicle_ID integer PRIMARY KEY, 
	Charging_points text, 
	City_locations text NOT NULL, 
	Customer_id integer NOT NULL,
	Status text NOT NULL,);""")


con.close()
