from django.urls import path
from . import views

urlpatterns = [

    path('', views.home, name='home'),

    path('select_login/', views.select_login, name="select_login"),
    path('login_customer/', views.login_customer, name="login_customer"),
    path('login_operator/', views.login_operator, name="login_operator"),
    path('login_manager/', views.login_manager, name="login_manager"),
    path('signup/', views.signup_func, name="signup"),
    path('logout/', views.logout_func, name="logout"),
    path('after_login_customer/', views.after_login_customer, name="after_login_customer"),
    path('after_login_customer/rent/', views.after_login_customer_rent, name='after_login_customer_rent'),
    path('after_login_customer/return/', views.after_login_customer_return, name='after_login_customer_return'),
    path('after_login_customer/pay/', views.after_login_customer_pay, name='after_login_customer_pay'),
    path('after_login_customer/report/', views.after_login_customer_report, name='after_login_customer_report'),
    path('after_login_operator/', views.after_login_operator, name="after_login_operator"),
    path('after_login_operator/track/', views.after_login_operator_track, name="after_login_operator_track"),
    path('after_login_operator/charge/', views.after_login_operator_charge, name="after_login_operator_charge"),
    path('after_login_operator/move/', views.after_login_operator_move, name="after_login_operator_move"),
    path('after_login_operator/repair/', views.after_login_operator_repair, name="after_login_operator_repair"),
    path('after_login_manager/', views.after_login_manager, name="after_login_manager"),
    path('after_login_manager/generate_reports/', views.after_login_manager_generate_reports, name="after_login_manager_generate_reports"),
    path('after_login_manager/generate_reports/show_reports/', views.after_login_manager_show_reports, name="after_login_manager_show_reports"),
    path('after_login_manager/signup_operator/', views.after_login_manager_signup_operator, name="after_login_manager_signup_operator"),
    path('after_login_manager/user_info/', views.after_login_manager_user_info, name="after_login_manager_user_info"),
]
